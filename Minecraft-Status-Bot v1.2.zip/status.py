import discord
import asyncio
from mcstatus import JavaServer, BedrockServer

# 從 TOKEN.txt 讀取 Token
def get_token():
    with open("TOKEN.txt", "r", encoding="utf-8") as file:
        return file.read().strip()

TOKEN = get_token()

# 伺服器 IP 和端口
JAVA_SERVER = "ouo.freeserver.tw"
JAVA_PORT = 24030

BEDROCK_SERVER = "ouo.freeserver.tw"
BEDROCK_PORT = 24030

# 伺服器官網 IP
SERVER_WEBSITE = "https://whitecloud.us.kg"

# 設定 Discord 頻道 ID
CHANNEL_ID = 1335773767900594268

# 設定 Bot 權限
intents = discord.Intents.default()
client = discord.Client(intents=intents)

# 版本資訊 (Bedrock 可在此處修改)
BEDROCK_VERSION_RANGE = "1.21.40 ~ 1.21.51"  # 更新至 1.21.51

@client.event
async def on_ready():
    print(f"已登入為 {client.user}")
    await send_status_loop()

async def send_status_loop():
    """每 40 秒更新一次伺服器狀態到指定頻道"""
    await client.wait_until_ready()
    channel = client.get_channel(CHANNEL_ID)
    if not channel:
        print("找不到指定的頻道，請確認 CHANNEL_ID 是否正確")
        return

    message = None
    while not client.is_closed():
        # 取得伺服器狀態
        try:
            java_status = JavaServer.lookup(f"{JAVA_SERVER}:{JAVA_PORT}").status()
            java_online = java_status.players.online
            java_max = java_status.players.max
            java_latency = round(java_status.latency)  # 四捨五入到整數
            java_status_text = "在線🟢"
            try:
                java_version = java_status.version.name  # 取得伺服器版本號碼
            except AttributeError:
                java_version = "無法偵測❌"  # 如果無法偵測，則顯示 "無法偵測"
        except Exception:
            java_online, java_max, java_latency = "N/A", "N/A", "N/A"
            java_status_text = "離線🔴"
            java_version = "N/A"

        try:
            bedrock_status = BedrockServer.lookup(f"{BEDROCK_SERVER}:{BEDROCK_PORT}").status()
            bedrock_online = bedrock_status.players.online  # 使用 players.online
            bedrock_max = bedrock_status.players.max  # 使用 players.max
            bedrock_latency = round(bedrock_status.latency)  # 四捨五入到整數
            bedrock_status_text = "在線🟢"
        except Exception:
            bedrock_online, bedrock_max, bedrock_latency = "N/A", "N/A", "N/A"
            bedrock_status_text = "離線❌"

        # 列印玩家數量 (除錯步驟1)
        print(f"Java 線上人數: {java_online}, Bedrock 線上人數: {bedrock_online}")

        countdown = 40

        # 更新訊息
        while countdown > 0:
            # 根據伺服器狀態設定顏色
            if java_status_text == "在線🟢" and bedrock_status_text == "在線🟢":
                embed_color = 0x00ff00  # 鮮綠色
            else:
                embed_color = 0xff0000  # 紅色

            embed = discord.Embed(title="Minecraft 伺服器狀態", color=embed_color)

            # Java 版資訊
            java_players = f"{java_online}/{java_max}" if java_online != "N/A" else "N/A"
            embed.add_field(name="Java 版", value=f"狀態: {java_status_text}\n玩家: {java_players}\n延遲: {java_latency} ms\n版本: {java_version}", inline=True)  # 只顯示版本號碼

            # Bedrock 版資訊
            bedrock_players = f"{bedrock_online}/{bedrock_max}" if bedrock_online != "N/A" else "N/A"
            embed.add_field(name="Bedrock 版", value=f"狀態: {bedrock_status_text}\n玩家: {bedrock_players}\n延遲: {bedrock_latency} ms\n版本: {BEDROCK_VERSION_RANGE}", inline=True)

            # 伺服器官網連結
            embed.add_field(name="伺服器官網", value=f"[點擊這裡查看]({SERVER_WEBSITE})", inline=False)

            # 下次刷新時間
            embed.set_footer(text=f"下次刷新: {countdown} 秒後")

            if message is None:
                message = await channel.send(embed=embed)
            else:
                await message.edit(embed=embed)

            countdown -= 1
            await asyncio.sleep(1)

client.run(TOKEN)
