import discord
from discord.ext import tasks
from mcstatus import JavaServer
import asyncio
import datetime
import mcstatus

class PixelPulseBot(discord.Client):
    def __init__(self, intents, server_config):
        super().__init__(intents=intents)
        self.status_message = None
        self.server_channels = {}
        self.server_config = server_config
        self.update_interval = 30
        self.lock = asyncio.Lock()

    async def on_ready(self):
        print(f'Bot已連線：{self.user}')
        await self.load_server_channels()
        self.pulse_check.start()

    async def load_server_channels(self):
        self.server_channels = {'default': 1355817659454980150}  # 替換成你的頻道ID

    def create_server_embed(self, server_statuses):
        embed = discord.Embed(
            title="拓荒之地伺服器狀態",
            description="當前伺服器狀態",
            color=discord.Color.green() if all(status['online'] for status in server_statuses.values()) else discord.Color.red()
        )

        total_players = 0
        server_count = 0

        for server_name, status in server_statuses.items():
            status_text = "<a:ServerUp:1368497817471029289> 線上" if status['online'] else "<a:ServerDown:1368498073952718848> 離線"
            ping_text = self.get_ping_status_text(status['ping'])
            player_count_text = self.format_player_count(status)

            embed.add_field(
                name=server_name,
                value=f"狀態：{status_text}\n延遲：{ping_text}\n{player_count_text}",
                inline=True
            )

            if status['online']:
                total_players += status['players_online']
                server_count += 1

        # Geyser 模式玩家數計算
        geyser_mode = self.server_config.get('geyser_mode', False)

        if geyser_mode:
            if server_count > 1:
                total_players //= 2
            
            embed.add_field(name="總玩家人數", value=str(total_players), inline=False)

        embed.timestamp = datetime.datetime.utcnow()

        return embed

    def get_ping_status_text(self, ping):
        if ping < 50:
            return f"{ping}ms <:ping1:1359200429656899695>"
        elif ping < 150:
            return f"{ping}ms <:ping2:1359200526096535562>"
        elif ping < 300:
            return f"{ping}ms <:ping3:1359200623760900107>"
        elif ping < 500:
            return f"{ping}ms <:ping4:1359200694757757112>"
        else:
            return f"{ping}ms <:ping5:1359200771798859968>"

    def format_player_count(self, status):
        if status['online']:
            if status.get('is_bungeecord', False):
                return f"總玩家人數：{status['players_online']}"
            else:
                return f"玩家人數：{status['players_online']}/{status['players_max']}"
        else:
            return "玩家人數：N/A"

    async def fetch_server_status(self, host, port):
        try:
            server = JavaServer.lookup(f"{host}:{port}")
            status = server.status()
            return {
                "online": True,
                "ping": round(status.latency),
                "players_online": status.players.online,
                "players_max": status.players.max
            }
        except Exception:
            return {
                "online": False,
                "ping": 0,
                "players_online": 0,
                "players_max": 0
            }

    @tasks.loop(seconds=30)
    async def pulse_check(self):
        async with self.lock:
            server_statuses = {}
            for server_name, server_info in self.server_config["servers"].items():
                status = await self.fetch_server_status(server_info['host'], server_info['port'])
                status['is_bungeecord'] = server_info.get('is_bungeecord', False)
                server_statuses[server_name] = status

            embed = self.create_server_embed(server_statuses)

            for channel_id in self.server_channels.values():
                channel = self.get_channel(channel_id)
                if channel:
                    try:
                        if self.status_message is None:
                            self.status_message = await channel.send(embed=embed)
                        else:
                            await self.status_message.edit(embed=embed)
                    except discord.errors.HTTPException as e:
                        print(f"更新訊息時發生錯誤：{e}")
                        self.status_message = await channel.send(embed=embed)

    @pulse_check.before_loop
    async def before_pulse_check(self):
        await self.wait_until_ready()

    async def close(self):
        if self.status_message:
            try:
                await self.status_message.delete()
                print("已刪除狀態訊息")
            except Exception as e:
                print(f"刪除訊息時發生錯誤：{e}")
        await super().close()

def main():
    intents = discord.Intents.default()
    intents.message_content = True

    server_config = {
        "geyser_mode": True,
        "servers": {
            "Java版本": {"host": "ouo.freeserver.tw", "port": 24488, "is_bungeecord": False},
            "Bedrock版本": {"host": "ouo.freeserver.tw", "port": 24488, "is_bungeecord": False}
        }
    }

    bot = PixelPulseBot(intents, server_config)
    bot.run('你的Bot Token') 

if __name__ == "__main__":
    main()